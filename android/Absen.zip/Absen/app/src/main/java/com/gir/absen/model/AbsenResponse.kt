package com.gir.absen.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AbsenResponse {

    @SerializedName("status")
    @Expose
    var status : Int?=null

    @SerializedName("pesan")
    @Expose
    var pesan : String?=null

}