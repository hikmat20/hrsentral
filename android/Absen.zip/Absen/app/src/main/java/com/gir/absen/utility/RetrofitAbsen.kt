package com.gir.absen.utility

import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.InputStream
import java.net.URL
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory

class RetrofitAbsen {
    fun getRetroClientInstance(): Retrofit {
        val gson = GsonBuilder().setLenient().create()
        return Retrofit.Builder()
            //.baseUrl("http://202.77.105.101:1515/absensi/")
            .baseUrl("http://sentral.dutastudy.com/hrsentral/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }
}