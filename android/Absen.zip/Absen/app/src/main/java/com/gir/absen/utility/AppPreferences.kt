package com.gir.absen.utility

import android.content.Context
import android.content.SharedPreferences

object AppPreferences {
    private const val NAME = "AbsensiSisem"
    private const val MODE = Context.MODE_PRIVATE
    private lateinit var preferences: SharedPreferences

    //SharedPreferences variables
    private val IS_LOGIN = Pair("is_login", false)
    private val USERNAME = Pair("username", "")
    private val PASSWORD = Pair("password", "")
    private val NAMA = Pair("nama", "")
    private val LAST_STATUS = Pair("last_status", "")
    private val LAST_TIME = Pair("last_time", "")

    fun init(context: Context) {
        preferences = context.getSharedPreferences(NAME, MODE)
    }

    //an inline function to put variable and save it
    private inline fun SharedPreferences.edit(operation: (SharedPreferences.Editor) -> Unit) {
        val editor = edit()
        operation(editor)
        editor.apply()
    }

    //SharedPreferences variables getters/setters
    var isLogin: Boolean
        get() = preferences.getBoolean(IS_LOGIN.first, IS_LOGIN.second)
        set(value) = preferences.edit {
            it.putBoolean(IS_LOGIN.first, value)
        }

    var username: String
        get() = preferences.getString(USERNAME.first, USERNAME.second) ?: ""
        set(value) = preferences.edit {
            it.putString(USERNAME.first, value)
        }

    var password: String
        get() = preferences.getString(PASSWORD.first, PASSWORD.second) ?: ""
        set(value) = preferences.edit {
            it.putString(PASSWORD.first, value)
        }

    var nama: String
        get() = preferences.getString(NAMA.first, NAMA.second) ?: ""
        set(value) = preferences.edit {
            it.putString(NAMA.first, value)
        }

    var last_status: String
        get() = preferences.getString(LAST_STATUS.first, LAST_STATUS.second) ?: ""
        set(value) = preferences.edit {
            it.putString(LAST_STATUS.first, value)
        }

    var last_time: String
        get() = preferences.getString(LAST_TIME.first, LAST_TIME.second) ?: ""
        set(value) = preferences.edit {
            it.putString(LAST_TIME.first, value)
        }
}