package com.gir.absen.utility

import android.app.Application

class APrefApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppPreferences.init(this)
    }
}