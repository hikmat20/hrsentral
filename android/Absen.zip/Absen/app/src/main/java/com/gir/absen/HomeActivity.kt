package com.gir.absen

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gir.absen.model.MenuRequest
import com.gir.absen.model.MenuResponse
import com.gir.absen.service.AbsenApi
import com.gir.absen.utility.AppPreferences
import com.gir.absen.utility.MenuAdapter
import com.gir.absen.utility.RetrofitAbsen
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val website : LinearLayout= findViewById(R.id.website)
        website.setOnClickListener {
            val intent = Intent(this, SiteActivity::class.java)
            startActivity(intent)
        }

        val signout : LinearLayout= findViewById(R.id.signout)
        signout.setOnClickListener {

            AppPreferences.isLogin = false
            AppPreferences.username = ""
            AppPreferences.password = ""
            AppPreferences.nama = ""

            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("jenis_absen","Lembur Keluar")
            startActivity(intent)
            finish()
        }

        val request= MenuRequest()
        request.nav="ctipe"

        val progress = ProgressDialog(this)
            progress.setTitle("Loading")
            progress.setMessage("Wait while loading...")
            progress.setCancelable(false)
            progress.show()

        val retro = RetrofitAbsen().getRetroClientInstance().create(AbsenApi::class.java)
        retro.menu(request).enqueue(object : Callback<List<MenuResponse>> {
            override fun onResponse(call: Call<List<MenuResponse>>, response: Response<List<MenuResponse>>) {

                //val last_status : TextView = findViewById(R.id.last_status)
                //last_status.text=AppPreferences.last_status
                val nama_user : TextView = findViewById(R.id.nama_user)
                nama_user.text=AppPreferences.nama

                showData(response.body()!!)
            }
            override fun onFailure(call: Call<List<MenuResponse>>, t: Throwable) {
                Log.e("Data Error", "datanya"+call)
            }

        })

        progress.dismiss()
    }

    private fun showData(menu: List<MenuResponse>){
        var recyclerView: RecyclerView =findViewById(R.id.recyclerView)
        recyclerView.apply{
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = MenuAdapter(menu, object : MenuAdapter.OnAdapterListener{
                override fun onClick(menu: MenuResponse) {
                    //Toast.makeText(applicationContext, "Nama="+jadwal.waktu, Toast.LENGTH_SHORT).show()
                    if(menu.id=="1" || menu.id=="4"){
                        val intent = Intent(applicationContext, JadwalActivity::class.java)
                        intent.putExtra("id_absen", menu.id)
                        intent.putExtra("jenis_absen", menu.nama)
                        startActivity(intent)
                    }else {
                        val intent = Intent(applicationContext, RecordActivity::class.java)
                        intent.putExtra("jenis_absen",menu.nama)
                        intent.putExtra("ctipe",menu.id)
                        intent.putExtra("range_waktu","")
                        intent.putExtra("lokasi", "")
                        intent.putExtra("standar_id", "")
                        startActivity(intent)
                    }
                }
            })
        }
    }
}