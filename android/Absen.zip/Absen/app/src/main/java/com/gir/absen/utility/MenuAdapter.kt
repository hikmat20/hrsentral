package com.gir.absen.utility

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gir.absen.R
import com.gir.absen.model.Jadwal
import com.gir.absen.model.MenuResponse

class MenuAdapter(
    private val menuList:List<MenuResponse>,
    private val listener:OnAdapterListener
):
    RecyclerView.Adapter<MenuAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.menu_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val menu = menuList[position]

        //holder.atId.text = menu.id
        holder.atNama.text = menu.nama

        holder.container.setOnClickListener {
            listener.onClick(menu)
        }
    }

    interface OnAdapterListener{
        fun onClick(menu: MenuResponse)
    }

    override fun getItemCount() = menuList.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val container : RelativeLayout = view.findViewById(R.id.menu_item)
        //val atId: TextView = view.findViewById(R.id.atid)
        val atNama: TextView = view.findViewById(R.id.atnama)
    }
}
