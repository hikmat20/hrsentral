package com.gir.absen.utility

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.gir.absen.R
import com.gir.absen.model.Jadwal


class JadwalAdapter(
    private val jadwalList: List<Jadwal>,
    private val listener:OnAdapterListener
):
    RecyclerView.Adapter<JadwalAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.jadwal_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val jadwal = jadwalList[position]

        holder.atLokasi.text = jadwal.nama
        holder.atWaktu.text = jadwal.waktu

        holder.container.setOnClickListener {
            listener.onClick(jadwal)
        }
    }

    interface OnAdapterListener{
        fun onClick(jadwal: Jadwal)
    }

    override fun getItemCount() = jadwalList.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val container :RelativeLayout = view.findViewById(R.id.jadwal_item)
        val atLokasi: TextView = view.findViewById(R.id.atLokasi)
        val atWaktu: TextView = view.findViewById(R.id.atWaktu)
    }
}
