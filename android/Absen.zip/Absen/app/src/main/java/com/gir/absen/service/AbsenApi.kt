package com.gir.absen.service

import com.gir.absen.model.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface AbsenApi {
    @POST("api_absen.php")
    fun login(
        @Body userRequest: UserRequest
    ):retrofit2.Call<UserResponse>

    //@Multipart
    @POST("api_absen.php")
    fun absen(
        @Body absenRequest: AbsenRequest
    ):retrofit2.Call<AbsenResponse>

    @POST("api_absen.php")
    fun menu(
        @Body menuRequest: MenuRequest
    ):retrofit2.Call<List<MenuResponse>>

    @POST("api_absen.php")
    fun jadwal(
        @Body jadwalRequest: JadwalRequest
    ):retrofit2.Call<List<Jadwal>>
}