package com.gir.absen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import com.gir.absen.model.UserRequest
import com.gir.absen.model.UserResponse
import com.gir.absen.service.AbsenApi
import com.gir.absen.utility.AppPreferences
import com.gir.absen.utility.RetrofitAbsen
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.math.BigInteger
import java.security.MessageDigest
import javax.net.ssl.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        if (AppPreferences.isLogin) {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

        val btn_login : TextView = findViewById(R.id.btn_login)
        btn_login.setOnClickListener{
            login()
        }
    }

    fun md5(input:String): String {
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
    }

    private fun login() {
        val request= UserRequest()

        var et_username : EditText= findViewById(R.id.et_username)
        var et_password : EditText= findViewById(R.id.et_password)

        val username=et_username.text.toString().trim()
        val password=et_password.text.toString().trim()

        val username_md5=md5(username)
        Log.e("md5=", username_md5)

        if (username.isNotBlank() && password.isNotBlank()) {

            request.username= username_md5
            request.password= et_password.text.toString().trim()
            request.nav="login"

            val retro = RetrofitAbsen().getRetroClientInstance().create(AbsenApi::class.java)
            retro.login(request).enqueue(object : Callback<UserResponse> {
                override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                    val user = response.body()

                    Log.e("md5=", username_md5)
                    Log.e("User=", user!!.pesan.toString().trim())
                    Log.e("Name=", user!!.status.toString().trim())

                    Toast.makeText(this@LoginActivity, user!!.pesan.toString().trim(), Toast.LENGTH_SHORT).show()

                    val responstatus = user!!.status.toString().trim()
                    if(responstatus=="1"){
                        val et_remember : CheckBox = findViewById(R.id.et_remember)
                        if(et_remember.isChecked()) {
                            AppPreferences.isLogin = true
                            AppPreferences.username = username
                            AppPreferences.password = password
                            AppPreferences.nama = user.nama.toString()
                        }
                        val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                        startActivity(intent)
                        finish()
                    }else{
                        Toast.makeText(this@LoginActivity, "Login Gagal!", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                    Log.e("Error", t.localizedMessage)
                }
            })
        } else {
            Toast.makeText(this@LoginActivity, "Input Username Dan Password!", Toast.LENGTH_SHORT).show()
        }
    }

}