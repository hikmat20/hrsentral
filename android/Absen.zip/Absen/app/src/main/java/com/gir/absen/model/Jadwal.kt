package com.gir.absen.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

//data class Jadwal (
//    val nilai:String,
//    val waktu:String,
//    val lokasi:String
//)


class Jadwal{
        @SerializedName("id")
        @Expose
        var id: String? = null

        @SerializedName("waktu")
        @Expose
        var waktu: String? = null

        @SerializedName("nama")
        @Expose
        var nama: String? = null
}


/*
class Jadwal{

    @SerializedName("status")
    @Expose
    var status : Int?=null

    @SerializedName("pesan")
    @Expose
    var pesan : String?=null

    @SerializedName("data")
    @Expose
    var data : Data?=null

    class Data(){
        @SerializedName("id")
        @Expose
        var id : String?=null

        @SerializedName("nama")
        @Expose
        var nama : String?=null
    }
}
*/