package com.gir.absen

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.gir.absen.utility.AppPreferences
import java.math.BigInteger
import java.security.MessageDigest

class SiteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_site)

        var username = AppPreferences.username
        var password = AppPreferences.password
        username = md5(username)
        val myWebView: WebView = findViewById(R.id.webview)
        var urlTarget = "https://sentral.dutastudy.com/hrsentral/api_absen.php?nav=aplikasi&username="+username+"&password="+password
        myWebView.loadUrl(urlTarget)
        myWebView.webViewClient = WebViewClient()
        myWebView.settings.javaScriptEnabled = true
    }

    fun md5(input:String): String {
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
    }
}