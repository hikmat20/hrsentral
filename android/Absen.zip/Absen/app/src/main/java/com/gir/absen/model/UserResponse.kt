package com.gir.absen.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

//data class UserResponse(
//    //val data: List<List<String>>,
//    val data:String,
//    val pesan: String,
//    val status: Int
//)

class UserResponse {
    @SerializedName("status")
    @Expose
    var status : Int?=null

    @SerializedName("pesan")
    @Expose
    var pesan : String?=null

    @SerializedName("id")
    @Expose
    var id : String?=null

    @SerializedName("nama")
    @Expose
    var nama : String?=null
}