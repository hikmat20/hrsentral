package com.gir.absen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gir.absen.model.Jadwal
import com.gir.absen.model.JadwalRequest
import com.gir.absen.service.AbsenApi
import com.gir.absen.utility.JadwalAdapter
import com.gir.absen.utility.RetrofitAbsen
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class JadwalActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jadwal)

        val request= JadwalRequest()
        request.nav="standar"
        val retro = RetrofitAbsen().getRetroClientInstance().create(AbsenApi::class.java)
        retro.jadwal(request).enqueue(object : Callback<List<Jadwal>> {
            override fun onResponse(call: Call<List<Jadwal>>, response: Response<List<Jadwal>>) {
                val jenis_absen = intent.getStringExtra("jenis_absen").toString()
                val jenisabsen : TextView = findViewById(R.id.at_jenisabsen)
                jenisabsen.text=jenis_absen
                val ctipe = intent.getStringExtra("id_absen").toString()
                showData(response.body()!!, jenis_absen, ctipe)
            }
            override fun onFailure(call: Call<List<Jadwal>>, t: Throwable) {
                Log.e("Data Error", "datanya"+call)
            }
        })
    }

    private fun showData(jadwal: List<Jadwal>, jenis_absen:String, ctipe:String){
        var recyclerView: RecyclerView =findViewById(R.id.recyclerView)
        recyclerView.apply{
            layoutManager = LinearLayoutManager(this@JadwalActivity)
            adapter = JadwalAdapter(jadwal, object :JadwalAdapter.OnAdapterListener{
                override fun onClick(jadwal: Jadwal) {
                    val intent = Intent(applicationContext, RecordActivity::class.java)
                    intent.putExtra("jenis_absen",jenis_absen)
                    intent.putExtra("ctipe",ctipe)
                    intent.putExtra("range_waktu",jadwal.waktu)
                    intent.putExtra("lokasi", jadwal.nama)
                    intent.putExtra("standar_id", jadwal.id)
                    startActivity(intent)
                    finish()
                }
            })
        }
    }
}