package com.gir.absen.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuRequest {
    @SerializedName("nav")
    @Expose
    var nav : String?=null
}