package com.gir.absen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import com.gir.absen.utility.AppPreferences

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val status : TextView= findViewById(R.id.status)
        status.text = AppPreferences.nama

        val last_status : TextView= findViewById(R.id.last_status)
        last_status.text = AppPreferences.last_status

        val last_time : TextView= findViewById(R.id.last_time)
        last_time.text = AppPreferences.last_time


        val absenmasuk : LinearLayout = findViewById(R.id.absenmasuk)
        absenmasuk.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Absen Masuk")
            startActivity(intent)
            finish()
        }

        val absenpulang : LinearLayout= findViewById(R.id.absenpulang)
        absenpulang.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Absen Pulang")
            startActivity(intent)
            finish()
        }
        val onsitemasuk : LinearLayout= findViewById(R.id.onsitemasuk)
        onsitemasuk.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Onsite Masuk")
            startActivity(intent)
            finish()
        }
        val onsitekeluar : LinearLayout= findViewById(R.id.onsitekeluar)
        onsitekeluar.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Onsite Keluar")
            startActivity(intent)
            finish()
        }
        val lemburmasuk : LinearLayout= findViewById(R.id.lemburmasuk)
        lemburmasuk.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Lembur Masuk")
            startActivity(intent)
            finish()
        }
        val lemburkeluar : LinearLayout= findViewById(R.id.lemburkeluar)
        lemburkeluar.setOnClickListener {
            val intent = Intent(this, JadwalActivity::class.java)
            intent.putExtra("jenis_absen","Lembur Keluar")
            startActivity(intent)
        }
        val website : LinearLayout = findViewById(R.id.website)
        website.setOnClickListener {
            val intent = Intent(this, SiteActivity::class.java)
            startActivity(intent)
        }

    }


}