package com.gir.absen.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AbsenRequest {
    @SerializedName("username")
    @Expose
    var username : String?=null

    @SerializedName("password")
    @Expose
    var password : String?=null

    @SerializedName("ctipe")
    @Expose
    var ctipe : String?=null

    @SerializedName("standar")
    @Expose
    var standar : String?=null

    @SerializedName("image")
    @Expose
    var image : String?=null

    @SerializedName("latitude")
    @Expose
    var latitude : String?=null

    @SerializedName("longitude")
    @Expose
    var longitude : String?=null

    @SerializedName("nav")
    @Expose
    var nav : String?=null

}