package com.gir.absen

import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.*

import android.util.Log
import android.widget.*
import com.gir.absen.model.AbsenRequest
import com.gir.absen.model.AbsenResponse
import com.gir.absen.service.AbsenApi
import com.gir.absen.utility.AppPreferences
import com.gir.absen.utility.RetrofitAbsen
import okhttp3.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream

import android.widget.TextView

import android.util.Base64
import java.math.BigInteger
import java.security.MessageDigest

class RecordActivity : AppCompatActivity() {

    private var our_request_code : Int = 123
    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var bitmap: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)
            //Get Permitiona Location
            fusedLocationProviderClient=LocationServices.getFusedLocationProviderClient(this)

            val ctipe = intent.getStringExtra("ctipe")
            val jenis_absen = intent.getStringExtra("jenis_absen")
            val lokasi = intent.getStringExtra("lokasi")
            val standar = intent.getStringExtra("standar_id")

            val at_ctipe : TextView = findViewById(R.id.at_ctipe)
            at_ctipe.text=ctipe
            val jenisabsen : TextView = findViewById(R.id.jenisabsen)
            jenisabsen.text=jenis_absen
            val nama_user : TextView = findViewById(R.id.nama_user)
            nama_user.text=AppPreferences.nama
            val jadwal_lokasi : TextView = findViewById(R.id.departemen)
            jadwal_lokasi.text=lokasi
            val at_standar : TextView = findViewById(R.id.at_standar)
            at_standar.text=standar

            val intent= Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if(intent.resolveActivity(packageManager)!=null){
            startActivityForResult(intent, our_request_code)
        }
        initAction()
    }

    fun takePhoto(view : View){
        //Intent to take picture
        val intent= Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if(intent.resolveActivity(packageManager)!=null){
            startActivityForResult(intent, our_request_code)
        }else{
            Log.e("Error", "Foto is Empty")
        }
    }

    private fun initAction() {
        val buttonAbsen = findViewById<Button>(R.id.buttonAbsen)
        buttonAbsen.setOnClickListener{
            prosesAbsen()
        }
    }

    fun md5(input:String): String {
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
    }

    private fun prosesAbsen(){
        val progress = ProgressDialog(this)
        progress.setTitle("Loading")
        progress.setMessage("Wait while loading...")
        progress.setCancelable(false)

        progress.show()

        //Get Location
        fetchlocation()

        val request= AbsenRequest()
        val at_ctipe : TextView= findViewById(R.id.at_ctipe)
        var et_jenisabsen : TextView= findViewById(R.id.jenisabsen)
        var et_latitude : TextView= findViewById(R.id.et_latitude)
        var et_longitude : TextView= findViewById(R.id.et_longitude)
        var et_foto : TextView= findViewById(R.id.imgbase)
        var get_standar : TextView= findViewById(R.id.at_standar)

        var getusername=AppPreferences.username
        getusername=md5(getusername)
        request.ctipe= at_ctipe.text.toString()
        request.username= getusername
        request.password= AppPreferences.password
        request.latitude= et_latitude.text.toString()
        request.longitude= et_longitude.text.toString()
        request.image= et_foto.text.toString()
        request.standar= get_standar.text.toString()
        request.nav="absensi"

//        Log.e("ctipe=", ">"+at_ctipe.text.toString())
//        Log.e("Standar=", ">"+get_standar.text.toString())
//        Log.e("username=", ">"+getusername)
//        Log.e("password=", ">"+AppPreferences.password)
//        Log.e("longitude=", ">"+et_longitude.text.toString())
//        Log.e("latitude=", ">"+et_latitude.text.toString())
//        Log.e("image=", ">"+et_foto.text.toString())

        val retrofit = RetrofitAbsen().getRetroClientInstance().create(AbsenApi::class.java)
        retrofit.absen(request).enqueue(object : Callback<AbsenResponse> {
            override fun onResponse(call: Call<AbsenResponse>, response: Response<AbsenResponse>) {
                val absen = response.body()
                //Log.e("Status=", absen!!.data?.status.toString().trim())
                Log.e("Status=", absen!!.status.toString().trim())
                Log.e("Pesan=", absen!!.pesan.toString().trim())
                val responstatus = absen!!.status.toString().trim()
                if(responstatus=="1"){
                    progress.dismiss()
                    //Add To Session
                    AppPreferences.last_status = et_jenisabsen.text.toString()
                    Toast.makeText(this@RecordActivity, "Absen Sukses", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@RecordActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish()
                }else{
                    Toast.makeText(this@RecordActivity, "Proses Absen Gagal!", Toast.LENGTH_SHORT).show()
                    progress.dismiss()
                }
            }
            override fun onFailure(call: Call<AbsenResponse>, t: Throwable) {
                Log.e("Error", t.localizedMessage)
                progress.dismiss()
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val buttonAbsen = findViewById<Button>(R.id.buttonAbsen)
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == our_request_code && resultCode == RESULT_OK){
            val imageview: ImageView =findViewById(R.id.foto)
            bitmap = data?.extras?.get("data") as Bitmap
            imageview.setImageBitmap(bitmap)

            val imgbase : TextView= findViewById(R.id.imgbase)
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
            val imageBytes: ByteArray = byteArrayOutputStream.toByteArray()
            val imageString: String
            imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT)
            imgbase.text = imageString
            //Log.e("Error", "Bitmapnya = "+bitmap)
            buttonAbsen.setVisibility(View.VISIBLE);

            //get location long lat
            fetchlocation()
        }else{
            Toast.makeText(this, "Ambil Foto Terlebih Dahulu!", Toast.LENGTH_SHORT).show()
            //Log.e("Error", "Take Your Foto First")
            buttonAbsen.setVisibility(View.GONE);
        }
    }

    private fun fetchlocation(){
        val task=fusedLocationProviderClient.lastLocation
        if(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED && ActivityCompat.
            checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }
        task.addOnSuccessListener {
            if(it!=null){
                //Toast.makeText(applicationContext, "${it.latitude} ${it.longitude}", Toast.LENGTH_SHORT).show()
                val et_latitude : TextView = findViewById(R.id.et_latitude)
                val et_longitude : TextView = findViewById(R.id.et_longitude)
                et_latitude.text="${it.latitude}"
                et_longitude.text="${it.longitude}"
            }
        }
    }
}