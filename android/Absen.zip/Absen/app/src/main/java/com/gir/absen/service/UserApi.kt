package com.gir.absen.service

import com.gir.absen.model.UserRequest
import com.gir.absen.model.UserResponse
import retrofit2.http.Body
import retrofit2.http.POST

interface UserApi_nouser {
    @POST("api_absen.php")
    fun login(
        @Body userRequest: UserRequest
    ):retrofit2.Call<UserResponse>
}